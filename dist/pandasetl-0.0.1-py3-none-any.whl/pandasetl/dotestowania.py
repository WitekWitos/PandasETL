import json

data_json = open(r"C:\Users\1\VSC\PandasETL\config\filesystem_config.json", encoding='utf-8')
data_json2 = open(r'C:\Users\1\VSC\PandasETL\config\features.json')
test = json.load(data_json)
test2 = json.load(data_json2)
lol = test['dropzone_path_customer']

print(lol)
